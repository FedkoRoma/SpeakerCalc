package com.example.speakercalc

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlin.math.*

class MainActivity : AppCompatActivity() {

    private var step = 0
    private var resistor = 0.0
    private var voltage = 0.0
    private var radius = 0.0
    private var fs = 0.0
    private var highVoltage = 0.0
    private var re = 0.0
    private var f1 = 0.0
    private var f2 = 0.0
    private var mass = 0.0
    private var fs2 = 0.0
    private var Sd = 0.0
    private var Rmax = 0.0
    private var Ro = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textStep = findViewById<TextView>(R.id.textStep)
        val input = findViewById<EditText>(R.id.inputValue)
        val btn = findViewById<Button>(R.id.btnNext)
        val result = findViewById<TextView>(R.id.resultText)

        updateStepText(textStep)

        btn.setOnClickListener {
            val value = input.text.toString().toDoubleOrNull() ?: return@setOnClickListener

            when (step) {
                0 -> resistor = value
                1 -> voltage = value
                2 -> { radius = value; Sd = Math.PI * radius * radius; result.append("Sd = $Sd\n") }
                3 -> fs = value
                4 -> highVoltage = value
                5 -> {
                    re = value
                    val X = resistor / voltage
                    Rmax = X * highVoltage
                    Ro = Rmax / re
                    val Rx = sqrt(Rmax * re)
                    voltage = Rx / X
                    result.append("Rmax = $Rmax\nVoltage = $voltage\n")
                }
                6 -> f1 = value
                7 -> {
                    f2 = value
                    if (f1 > f2) { val t = f1; f1 = f2; f2 = t }
                    val Qms = fs * sqrt(Ro) / (f2 - f1)
                    val Qes = Qms / (Ro - 1)
                    val Qts = Qms / Ro
                    result.append("Qms=$Qms\nQes=$Qes\nQts=$Qts\n")
                }
                8 -> mass = value
                9 -> {
                    fs2 = value
                    val avg = (fs + fs2) * (fs - fs2) / (fs * fs2).pow(2)
                    val Cms = avg / ((2 * Math.PI).pow(2) * mass)
                    val Vas = 1.4 * Cms * 100000 * Sd.pow(2) * 1000
                    result.append("Vas = $Vas L\n")
                }
            }

            step++
            input.text.clear()
            updateStepText(textStep)
        }
    }

    private fun updateStepText(text: TextView) {
        text.text = listOf(
            "Введіть опір",
            "Введіть напругу",
            "Радіус",
            "Fs",
            "Напруга резонансу",
            "Re",
            "F1",
            "F2",
            "Маса",
            "Fs2"
        ).getOrElse(step) { "Готово" }
    }
}
